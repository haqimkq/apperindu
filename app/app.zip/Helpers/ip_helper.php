<?php

function ip()
{
    return 'http://172.16.36.105/';
}
