<?php

namespace App\Models\Master;


use CodeIgniter\Model;

class M_pengguna_old extends Model
{
    protected $table = 'tblpengguna';
    protected $primaryKey = 'tblpengguna_id';
}
